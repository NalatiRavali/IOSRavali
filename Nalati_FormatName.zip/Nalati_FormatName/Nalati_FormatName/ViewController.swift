//
//  ViewController.swift
//  Nalati_FormatName
//
//  Created by Nalati,Ravali on 2/9/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var firstNameTextField: UITextField!
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    @IBAction func onClickOfSubmit(_ sender: UIButton) {
        displayLabel.text!="\(lastNameTextField.text!),\(firstNameTextField.text!)"
        
    }
    
    @IBAction func onClickOfReset(_ sender: UIButton) {
        firstNameTextField.text!=""
        lastNameTextField.text!=""
        displayLabel.text!=""
        firstNameTextField.becomeFirstResponder()
        
    }
    

    @IBOutlet weak var displayLabel: UILabel!
    
    
}

